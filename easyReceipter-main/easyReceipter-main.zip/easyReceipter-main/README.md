# easyReceipter
 Java end of stack project
 <h1>Hello World!</h1>
